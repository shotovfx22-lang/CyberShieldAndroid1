package com.cybershield.vpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import com.wireguard.config.Config
import java.io.BufferedInputStream

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var wireGuard: WireGuardController

    companion object {
        private const val REQUEST_VPN_PERMISSION = 4101
        private const val REQUEST_CONFIG_FILE = 4102
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(13, 20, 32)
        window.navigationBarColor = android.graphics.Color.rgb(8, 12, 21)

        wireGuard = WireGuardController(applicationContext) { state, message ->
            runOnUiThread { sendState(state, message) }
        }

        webView = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(8, 12, 21))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = false
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(AndroidBridge(), "AndroidVpn")
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun requestConnect() {
        val permissionIntent = VpnService.prepare(this)
        if (permissionIntent != null) {
            startActivityForResult(permissionIntent, REQUEST_VPN_PERMISSION)
        } else {
            wireGuard.connect()
        }
    }

    private fun chooseConfig() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/plain", "application/octet-stream"))
        }
        startActivityForResult(intent, REQUEST_CONFIG_FILE)
    }

    @Deprecated("Uses the platform Activity result API for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_VPN_PERMISSION -> {
                if (resultCode == RESULT_OK) wireGuard.connect()
                else sendState("error", "مجوز اتصال VPN توسط کاربر تأیید نشد.")
            }
            REQUEST_CONFIG_FILE -> {
                if (resultCode == RESULT_OK) {
                    val uri = data?.data ?: return
                    try {
                        contentResolver.openInputStream(uri)?.use { input ->
                            val parsed = Config.parse(BufferedInputStream(input))
                            wireGuard.setConfig(parsed)
                        } ?: sendState("error", "خواندن فایل کانفیگ ممکن نشد.")
                    } catch (error: Exception) {
                        sendState("error", "فایل کانفیگ معتبر نیست: ${error.localizedMessage ?: "خطای خواندن"}")
                    }
                }
            }
        }
    }

    private fun sendState(state: String, message: String?) {
        if (!::webView.isInitialized) return
        val safeState = state.replace("'", "")
        val safeMessage = org.json.JSONObject.quote(message ?: "")
        webView.evaluateJavascript(
            "window.onNativeVpnState && window.onNativeVpnState('$safeState', $safeMessage);",
            null
        )
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun connect() = runOnUiThread { requestConnect() }

        @JavascriptInterface
        fun disconnect() = wireGuard.disconnect()

        @JavascriptInterface
        fun importConfig() = runOnUiThread { chooseConfig() }

        @JavascriptInterface
        fun hasConfig(): Boolean = wireGuard.hasConfig()
    }

    override fun onDestroy() {
        if (::wireGuard.isInitialized) wireGuard.shutdown()
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("AndroidVpn")
            webView.destroy()
        }
        super.onDestroy()
    }
}
