package com.cybershield.vpn

import android.content.Context
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Thin adapter around the official embeddable WireGuard tunnel library.
 * Configurations are held in memory only; private keys are not written to app storage or logs.
 */
class WireGuardController(
    context: Context,
    private val onState: (state: String, message: String?) -> Unit
) {
    private val backend = GoBackend(context.applicationContext)
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    @Volatile private var config: Config? = null

    private val tunnel = object : Tunnel {
        override fun getName(): String = "CyberShield"

        override fun onStateChange(newState: Tunnel.State) {
            when (newState) {
                Tunnel.State.UP -> onState("connected", null)
                Tunnel.State.DOWN -> onState("disconnected", null)
                else -> Unit
            }
        }
    }

    fun setConfig(newConfig: Config) {
        config = newConfig
        onState("config", "کانفیگ WireGuard آماده است.")
    }

    fun hasConfig(): Boolean = config != null

    fun connect() {
        val selected = config
        if (selected == null) {
            onState("error", "ابتدا فایل کانفیگ WireGuard با پسوند .conf را وارد کنید.")
            return
        }
        executor.execute {
            try {
                backend.setState(tunnel, Tunnel.State.UP, selected)
                onState("connected", null)
            } catch (error: Exception) {
                onState("error", error.localizedMessage ?: "اتصال WireGuard ناموفق بود.")
            }
        }
    }

    fun disconnect() {
        executor.execute {
            try {
                backend.setState(tunnel, Tunnel.State.DOWN, null)
                onState("disconnected", null)
            } catch (error: Exception) {
                onState("error", error.localizedMessage ?: "قطع اتصال با خطا مواجه شد.")
            }
        }
    }

    fun shutdown() {
        executor.shutdown()
    }
}
